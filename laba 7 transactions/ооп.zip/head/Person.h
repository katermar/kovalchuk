#pragma once
#include "Header.h"

class Person 
{
protected:
	char name[20];
	char surname[20];
	int birth;
public:
	Person();
	Person(char *name, char *surname);
	Person(char *name, char *surname, int birth);
	Person(const Person &obj);
	virtual ~Person();
	char* getName();
	char* getSurname();
	int getBirth();
	void setName(char* str);
	void setSurname(char* str);
	void setBirth(int);
	void edge();

	friend ostream &operator<< (ostream &out, Person obj);
	friend istream &operator>> (istream &in, Person& bt);

	bool operator>(const Person& obj);
	bool operator>=(const Person& obj);
	bool operator<(const Person& obj);
	bool operator<=(const Person& obj);
	bool operator==(const Person& obj);
};
